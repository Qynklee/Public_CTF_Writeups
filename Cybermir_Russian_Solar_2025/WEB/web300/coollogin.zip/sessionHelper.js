// sessionHelper.js
module.exports = {
  initSession: function (req) {
    // "Запутанный" способ инициализации
    if (!req.session._solar) {
      req.session._solar = { messages: [], user: null };
    }
  },
  getUser: function (req) {
    return req.session._solar ? req.session._solar.user : null;
  },
  addMessage: function (req, msg) {
    if (req.session._solar) req.session._solar.messages.push(msg);
  },
  getMessages: function (req) {
    return req.session._solar ? req.session._solar.messages : [];
  },
  loginUser: function (req, user) {
    if (req.session._solar) req.session._solar.user = user;
    // Не делаем regenerate — CWE-384!
  }
};
