cool event registration form (medium)
==========================================

Legend
------
Знакомый попросил Вас зарегистрироваться на *"Очень крутое мероприятие"* и скинул Вам ссылку.
Открыв её, Вы обнаружили странную форму. Что может быть с ней не так?

Solution
--------
Участникам необходимо пройтись по HTML-полям и понять, что поля телефона и e-mail проверяются при помощи регулярок. Регулярки в этих полях "кривые" и подвержены REDoS. После чего необходимо подобрать корректные данные для этих полей, при которых приложение подвиснет более чем на 2 секунды.

При возникновении RE DoS приложение выдаст сообщение об ошибке, в котором, при помощи параметра fname, можно вызвать простенькую SSTI.

Пример запроса, роняющего в REDoS с последующим чтением файла флага:
```
fname={{request.application.__globals__.__builtins__.open('flag.txt').read()}}&sname=&date=2025-03-22&participants=2&phone=0<повторить несколько тысяч раз>%2B&email=&subscribe=on
```

Flag
----
solar{REd0s_s3r10u5ly?}


## Description

Your friend asked you to register for a *super cool event* and sent you a link.  
You notice a suspicious registration form. Can you spot what’s wrong with it?

You have full access to the source code and can run it locally.  
Your task is to find and exploit the vulnerabilities as a chain.  
Submit the CWE identifiers of the vulnerabilities you exploited, in the order of your attack chain.

**No flag is hidden in the code or UI. The only accepted flag is your vulnerability analysis!**

## Flag format

solar{CWE-XX,CWE-YY}

*Only the exact flag will be accepted.*
**Submit the CWE identifiers strictly in the order you exploit them.**


## Hints

- _Are all the regular expressions in the form safe against very large or specially crafted input?_
- _What happens to your input if the server hits an internal error?_

solar{CWE-1333,CWE-1336}