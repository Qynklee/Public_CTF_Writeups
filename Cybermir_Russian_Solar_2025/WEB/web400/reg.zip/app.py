"""solar ctf - cool event registration form."""
# -*- coding: utf-8 -*-

import argparse
import base64
import datetime
import hashlib
import html
import logging
import os
import sqlite3
import sys

import regex

from logging import info, warning, error
from flask import Flask, request, render_template_string
ISO_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
LOG_MSG_FORMAT = '%(asctime)s %(levelname)s: %(message)s'

PHONE_RE = r'^\+?((\d+\s*)+)$'
EMAIL_RE = r'^([^@]*[^@.])@([^@]+(?:\.[^@]+)*)$'

TEMPLATE = '''\
<!DOCTYPE html>
<html>
<head>
<title>{{ title }}</title>
<link rel="icon" type="image/png" href="/static/solar.svg">
<link rel="stylesheet" href="/static/style.css">
<script src="/static/jquery-3.6.0.min.js"></script>
<script src="/static/jquery.mask.min.js"></script>
<script>
$(document).ready(function(){
  $('#phone').mask('+9 (999) 999-99-99');
});
</script>
</head>
<body>
<div class="container">
<p><img class="icon">
<span class="title">solar ctf</span></p>
<p>{{ message }}</p>{% if internal_error %}
<p>dear {fname}, please contact to our support team!</p>
<button onclick="window.location='/'">return</button>
{% elif show_form %}<form method="POST">
<p><input type="text" name="fname" placeholder="first name*" value="{{ fname }}" maxlength=100 required></p>
<p><input type="text" name="sname" placeholder="second name" value="{{ sname }}" maxlength=100></p>
<p><input type="date" name="date" placeholder="expected date*" value="{{ date }}" min="{{ min_date }}" max="{{ max_date }}" required></p>
<p><input type="number" name="participants" placeholder="number of participants*" value="{{ participants }}" min=1 max=5 required></p>
<p><input type="tel" id="phone" name="phone" placeholder="phone* (ex. +7 (999) 999-99-99)" value="{{ phone }}" required></p>
<p><input type="email" name="email" placeholder="email" value="{{ email }}" maxlength=100></p>
<p><input type="checkbox" id="subscribe" name="subscribe"{{ subscribe }}>
<label for="subscribe">email me with news and updates</label></p>
<p><span class="orange">*</span>indicates a required field</p>
<button type="submit">register</button>
</form>{% else %}
<button onclick="window.location='/'">return</button>
{% endif %}</div>
</body>
</html>
'''
app = Flask(__name__)
title = sys.modules[__name__].__doc__.strip().rstrip('.')

@app.route('/', methods=['GET', 'POST'])
def index():
    message = 'cool event registration form 🥳'
    internal_error = False
    show_form = True

    fname=''
    sname=''
    participants=''
    phone=''
    email=''
    subscribe = True

    date_now = datetime.date.today()

    date_now = datetime.datetime(
        year=date_now.year,
        month=date_now.month,
        day=date_now.day
    )

    tomorrow = date_now + datetime.timedelta(days=1)
    max_date = date_now + datetime.timedelta(days=14)

    date = tomorrow

    try:
        if request.method == 'POST':
            info('incoming data from %s: %s',
                 request.remote_addr, dict(request.form))

            fname = request.form.get('fname', '')
            sname = request.form.get('sname', '')
            date_str = request.form.get('date', '')
            participants = request.form.get('participants', '')
            phone = request.form.get('phone', '')
            email = request.form.get('email', '')
            subscribe = bool(request.form.get('subscribe', '') == 'on')

            if not fname:
                raise Exception('first name is required 😊')

            elif len(fname) > 100:
                raise Exception('first name is too long 😐')

            if len(sname) > 100:
                raise Exception('second name is too long 😐')

            try:
                date = datetime.datetime.strptime(date_str, '%Y-%m-%d')
                days_delta = (date - tomorrow).days

                if days_delta < 0:
                    raise Exception('do you have a time travel machine? 👀')

                elif days_delta >= 14:
                    raise Exception(
                        'selected date is not available to register 😐'
                    )

            except ValueError:
                raise Exception('invalid date format 😡')

            try:
                participants_int = int(participants)

                if not 1 <= participants_int <= 5:
                    raise ValueError

            except ValueError:
                participants_int = 0
                raise Exception('invalid number of participants 😐')

            phone = phone.replace(' ', '').replace('(', '') \
                    .replace(')', '').replace('-', '')

            if not regex.match(PHONE_RE, phone,
                               flags=regex.IGNORECASE, timeout=2):
                raise Exception('invalid phone number 😡')

            if email:
                if not regex.match(EMAIL_RE, email.strip(' \r\n\t'),
                                   flags=regex.IGNORECASE, timeout=2):
                    raise Exception('invalid email 😡')

            message = 'you were successfully registered to our cool event! 😊'
            show_form = False

    except TimeoutError as exc:
        internal_error = True
        message = 'ouch... 😓'

    except Exception as exc:
        error(exc)
        message = f'error: {str(exc)}'

    if internal_error:
        template = TEMPLATE.replace('{fname}', fname)

    else:
        template = TEMPLATE.replace('{fname}', '')

    return render_template_string(
        template,
        title=title,
        message=message,
        internal_error=internal_error,
        show_form=show_form,
        fname=fname,
        sname=sname,
        participants=participants,
        phone=phone,
        email=email,
        subscribe=' checked' if subscribe else '',
        date=date.strftime('%Y-%m-%d'),
        min_date=tomorrow.strftime('%Y-%m-%d'),
        max_date=max_date.strftime('%Y-%m-%d')
    )

def init_log():
    """Init logging to display/file."""

    if os.path.isdir('/log/'):
        log_file = '/log/app.log'

    else:
        log_file = None

    for level in [(logging.INFO,    'info'),
                  (logging.WARNING, 'warning'),
                  (logging.ERROR,   'error')]:
        logging.addLevelName(*level)

    logging.basicConfig(level=logging.INFO,
                        datefmt=ISO_DATE_FORMAT,
                        format=LOG_MSG_FORMAT)

    if log_file is not None:
        filelog = logging.FileHandler(filename=log_file, mode='a',
                                      encoding='utf-8')

        filelog.setFormatter(logging.Formatter(datefmt=ISO_DATE_FORMAT,
                                               fmt=LOG_MSG_FORMAT))

        logging.getLogger().addHandler(filelog)

        info(f'logging to file: {log_file}')

    else:
        info('no file logging available')

def main():
    parser = argparse.ArgumentParser(
        description=sys.modules[__name__].__doc__.strip()
    )

    parser.add_argument('-p', '--port', type=int, default=5000,
                        help='http port for flask service')

    parser.add_argument('-d', '--debug', action='store_true',
                        help='start flask in debug mode')

    params = parser.parse_args()

    init_log()
    app.run(host='0.0.0.0', port=params.port, debug=params.debug)

if __name__ == '__main__':
    try:
        main()

    except KeyboardInterrupt:
        pass
